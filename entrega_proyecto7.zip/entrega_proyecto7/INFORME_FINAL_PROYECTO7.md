# Proyecto 7. Modelos open-source: ecosistema Hugging Face

## 1. Objetivo

Construir un clasificador experimental de consultas de una
aseguradora ficticia de automóviles utilizando un modelo de
lenguaje abierto, ajuste fino con LoRA y evaluación comparativa.

El sistema debe generar una respuesta en español con formato JSON
y los campos `category`, `priority` y `response`.

## 2. Modelo y herramientas

- Modelo base: Qwen/Qwen3-0.6B.
- Ecosistema: Hugging Face Transformers.
- Datos: Hugging Face Datasets.
- Ajuste fino: PEFT y LoRA.
- Entorno de ejecución: Google Colab con GPU Tesla T4.
- Datos de entrenamiento: 150 ejemplos sintéticos.
- Datos de validación: 30 ejemplos sintéticos.
- Datos de test: 30 ejemplos sintéticos.

## 3. Categorías y reglas de negocio

Categorías utilizadas:
- `siniestro`
- `poliza`
- `recibos`
- `asistencia`
- `documentacion`

Prioridades:
- `alta`
- `media`
- `baja`

Regla relevante: en este proyecto, las averías que requieren
asistencia en carretera se clasifican como `siniestro`.
Las consultas informativas sobre coberturas de asistencia,
sin una avería concreta, se clasifican como `asistencia`.

## 4. Configuración de LoRA

- Rango LoRA: 8.
- Alpha LoRA: 16.
- Learning rate: 0.0002.
- Épocas: 2.
- Batch size por dispositivo: 2.
- Gradient accumulation steps: 4.
- Pérdida final de entrenamiento registrada: 1.4102.

## 5. Evaluación final

Los tres enfoques se evaluaron sobre los mismos 30 ejemplos de
test. La validación del JSON fue estricta: no se repararon ni
corrigieron automáticamente las respuestas.

| Configuración | JSON válido | Categoría correcta | Prioridad correcta |
|---|---:|---:|---:|
| Modelo base + prompt básico | 6.67% | 3.33% | 3.33% |
| Modelo base + prompt V3 + few-shot | 100.00% | 83.33% | 63.33% |
| Adaptador LoRA V2 + prompt V3 | 53.33% | 53.33% | 36.67% |

## 6. Interpretación

En esta evaluación, el modelo base con prompt V3 y ejemplos
few-shot obtuvo los mejores resultados de las tres configuraciones.

El adaptador LoRA permitió completar el flujo de ajuste fino y
publicación, pero no superó al enfoque base con few-shot en el
test utilizado. La generación de JSON y la clasificación de
prioridades siguen siendo áreas de mejora.

## 7. Limitaciones

- Los datos son sintéticos y no representan clientes reales.
- El test contiene 30 ejemplos procedentes de seis grupos de
  consultas; las variantes de un mismo grupo están correlacionadas.
- Los resultados corresponden a una evaluación pequeña y no
  garantizan el comportamiento en datos reales.
- El sistema puede equivocarse en categorías, prioridades y
  recomendaciones incluidas en la respuesta.
- No debe utilizarse para decisiones reales sobre pólizas,
  siniestros, indemnizaciones o urgencias sin supervisión humana.

El test final se conserva como evaluación cerrada. No se debe
utilizar para ajustar el modelo y volver a presentar esos mismos
resultados como una evaluación independiente.

## 8. Publicación

Repositorio privado del adaptador:
https://huggingface.co/GMVDD/proyecto7-clasificador-seguros-lora

El repositorio contiene un adaptador PEFT/LoRA, no una copia
completa del modelo base.

## 9. Contenido de la entrega

- `datos/`: conjuntos sintéticos corregidos.
- `resultados/`: predicciones, resúmenes y diagnósticos.
- `metricas/`: métricas del entrenamiento.
- `modelo_lora/`: adaptador, configuración, tokenizador y tarjeta
  del modelo.
- Este informe: resumen del método, resultados y limitaciones.

## 10. Uso responsable y licencia

Proyecto educativo. No constituye un sistema asegurador listo
para producción. Antes de redistribuir públicamente los archivos,
deben comprobarse las licencias y condiciones de uso del modelo
base y de los componentes incluidos.
