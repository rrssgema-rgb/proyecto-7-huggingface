---
license: apache-2.0
base_model: Qwen/Qwen3-0.6B
tags:
- peft
- lora
- text-classification
- insurance
- synthetic-data
- spanish
---

# Clasificador de incidencias de seguros de automóvil — Proyecto 7

## Descripción

Adaptador LoRA experimental basado en Qwen3-0.6B, desarrollado
como parte de un proyecto académico de un máster en Inteligencia
Artificial.

El sistema clasifica consultas sintéticas de una aseguradora
ficticia de automóviles y genera una respuesta breve en español.

## Categorías

- `siniestro`: accidentes, daños y gestión de expedientes.
  Según la regla de negocio de este proyecto, las averías que
  requieren asistencia en carretera se contabilizan como siniestros.
- `poliza`: contratación, renovación, modificación o cancelación.
- `recibos`: consultas sobre recibos, pagos y primas.
- `asistencia`: consultas informativas sobre coberturas y condiciones
  de asistencia, sin gestionar una avería concreta.
- `documentacion`: solicitudes y problemas relativos a documentos
  del seguro.

## Prioridades

- `alta`: urgencia que requiere actuación inmediata.
- `media`: incidencia que necesita intervención o seguimiento.
- `baja`: trámite rutinario o consulta sin incidencia activa.

## Modelo base y técnica

- Modelo base: `Qwen/Qwen3-0.6B`.
- Técnica de ajuste: PEFT con LoRA.
- Rango LoRA (`r`): 8.
- Alpha LoRA: 16.
- Learning rate: 0.0002.
- Épocas: 2.
- Batch size por dispositivo: 2.
- Gradient accumulation steps: 4.
- Datos sintéticos de entrenamiento: 150 ejemplos.
- Datos de validación: 30 ejemplos.
- Datos de test: 30 ejemplos.

## Evaluación

La evaluación se realizó con tres configuraciones sobre los mismos
30 ejemplos de test, aplicando validación estricta del JSON y sin
reparar automáticamente las respuestas.

| Configuración | JSON válido | Categoría correcta | Prioridad correcta |
|---|---:|---:|---:|
| Modelo base + prompt básico | 6.67% | 3.33% | 3.33% |
| Modelo base + prompt V3 + few-shot | 100.00% | 83.33% | 63.33% |
| Adaptador LoRA V2 + prompt V3 | 53.33% | 53.33% | 36.67% |

Estos resultados corresponden a una evaluación académica pequeña
y sintética. No representan una garantía de rendimiento en
situaciones reales.

## Limitaciones y uso responsable

- Los datos son sintéticos y no representan clientes reales.
- El conjunto de test contiene 30 ejemplos procedentes de seis
  grupos de consultas; las variantes de un mismo grupo pueden
  estar correlacionadas.
- El adaptador LoRA V2 no superó al modelo base con few-shot en
  esta evaluación.
- La clasificación de prioridades y algunas distinciones semánticas
  siguen presentando errores.
- No debe utilizarse para tomar decisiones reales sobre pólizas,
  siniestros, indemnizaciones o urgencias sin validación humana.
- No se han incluido datos personales de clientes.
- Este proyecto es educativo y no constituye un sistema de
  asesoramiento asegurador listo para producción.

## Uso técnico

Este repositorio contiene un adaptador PEFT/LoRA, no una copia
completa de los pesos del modelo base. Para cargarlo se necesita
acceso al modelo base `Qwen/Qwen3-0.6B` y las dependencias
compatibles de Transformers y PEFT.

## Licencia

La licencia declarada para este adaptador es Apache-2.0.
Antes de redistribuirlo públicamente, comprueba la licencia y
las condiciones de uso del modelo base y de sus componentes.

## Autoría

Proyecto académico individual — Proyecto 7: Modelos open-source
y ecosistema Hugging Face.
