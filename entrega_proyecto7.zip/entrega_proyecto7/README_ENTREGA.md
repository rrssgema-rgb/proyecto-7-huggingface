# Contenido de la entrega

- `INFORME_FINAL_PROYECTO7.md`: resumen del proyecto.
- `datos/`: datos sintéticos corregidos para entrenamiento,
  validación y test.
- `resultados/`: predicciones y métricas de evaluación.
- `metricas/`: métricas de entrenamiento.
- `modelo_lora/`: adaptador PEFT/LoRA y archivos de configuración.

Repositorio Hugging Face:
https://huggingface.co/GMVDD/proyecto7-clasificador-seguros-lora

La evaluación final de test ya realizada no debe repetirse para
ajustar el modelo.
